﻿Public Interface ITransmitter
    Sub Start(ByVal packet As OscPacket)
    Sub [Stop]()
End Interface
