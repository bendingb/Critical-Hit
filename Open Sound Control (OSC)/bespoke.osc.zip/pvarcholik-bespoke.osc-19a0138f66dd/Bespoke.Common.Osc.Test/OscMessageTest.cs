﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bespoke.Common.Osc.Test
{
    [TestClass]
    public class OscMessageTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.Fail();
        }
    }
}
